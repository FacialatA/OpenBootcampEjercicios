inicial = 100

while inicial >= 1:
    print(inicial)
    inicial -= 1
